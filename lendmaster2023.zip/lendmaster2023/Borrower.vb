﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient
Imports Mysqlx.Cursor
Public Class Borrower
    Dim conn As MySqlConnection = New MySqlConnection
    Dim cmd As MySqlCommand = New MySqlCommand
    Dim dr As MySqlDataReader
    Dim sql, sql2, User As String
    Dim dt As DataTable
    Public Sub connect()

        cmd.CommandText = sql
        cmd.CommandType = CommandType.Text
        cmd.Connection = conn

        conn.Open()
        dr = cmd.ExecuteReader



    End Sub
    Private Sub Populate()
        conn.Open()
        Dim query = "select * from borrower1"
        Dim adapter As MySqlDataAdapter
        adapter = New MySqlDataAdapter(query, conn)
        Dim builder As MySqlCommandBuilder
        builder = New MySqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        BorrowerDGV.DataSource = ds.Tables(0)


        conn.Close()
    End Sub









    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Dim obj As New Dashboard()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Dim obj As New Borrower()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Dim obj As New loan()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Dim obj As New application()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        Dim obj As New payment()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click
        Dim obj As New report()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub

    Private Sub Borrower_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conn.ConnectionString = "server=localhost;user id=root;port=3306;password=#001;database=lendmaster"
        Populate()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        If Bname.Text = "" Then
            MessageBox.Show("Please Enter all the details")

        ElseIf Badhar.Text = "" Then
            MessageBox.Show("Please Enter all the details")

        ElseIf Baddress.Text = "" Then
            MessageBox.Show("Please Enter all the details")
        ElseIf Bemail.Text = "" Then
            MessageBox.Show("Please Enter all the details")
        ElseIf Bphone.Text = "" Then
            MessageBox.Show("Please Enter all the details")
        ElseIf Bsphone.Text = "" Then
            MessageBox.Show("Please Enter all the details")
        Else
            sql = "INSERT into borrower1(
                            Name,
                            Adhar_no,
                            Adress,
                            Email,
                            phone,
                            Secondary_phone
                            ) 
                    values(
                        
                        '" & Bname.Text & "',
                        '" & Badhar.Text & "',
                        '" & Baddress.Text & "',
                        '" & Bemail.Text & "',
                        '" & Bphone.Text & "',
                        '" & Bsphone.Text & "'
                    )  "

            connect()
            MessageBox.Show("Saved Succesfully")
            conn.Close()
            Populate()


        End If
        conn.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        sql = "update borrower1 set Name='" & Bname.Text & "',
                            Adhar_no='" & Badhar.Text & "',
                            Adress='" & Baddress.Text & "',
                            Email='" & Bemail.Text & "',
                            phone='" & Bphone.Text & "',
                            Secondary_phone='" & Bsphone.Text & "' 
                            where Bid='" & Key & "'   "
        connect()

        If Bname.Text = "" Then
            MessageBox.Show("Please Enter all the details")

        ElseIf Badhar.Text = "" Then
            MessageBox.Show("Please Enter all the details")

        ElseIf Baddress.Text = "" Then
            MessageBox.Show("Please Enter all the details")
        ElseIf Bemail.Text = "" Then
            MessageBox.Show("Please Enter all the details")
        ElseIf Bphone.Text = "" Then
            MessageBox.Show("Please Enter all the details")
        ElseIf Bsphone.Text = "" Then
            MessageBox.Show("Please Enter all the details")
        Else
            MessageBox.Show("updated successfully")
            conn.Close()
            Populate()


        End If
    End Sub
    Dim Key = 0
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        sql = "Delete from borrower1 where Bid=" & Key & ""

        connect()

        If Key = 0 Then
            MessageBox.Show("Select borrower information")




        Else
            MessageBox.Show("Deleted Succesfully")
            conn.Close()
            Populate()


        End If
    End Sub


    Private Sub BorrowerDGV_CellMouseClick_1(sender As Object, e As DataGridViewCellMouseEventArgs) Handles BorrowerDGV.CellMouseClick
        Dim row As DataGridViewRow = BorrowerDGV.Rows(e.RowIndex)
        Bname.Text = row.Cells(1).Value.ToString
        Badhar.Text = row.Cells(2).Value.ToString
        Baddress.Text = row.Cells(3).Value.ToString
        Bemail.Text = row.Cells(4).Value.ToString
        Bphone.Text = row.Cells(5).Value.ToString
        Bsphone.Text = row.Cells(6).Value.ToString
        If Bname.Text = "" Then
            Key = 0
        Else
            Key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If

    End Sub

    Private Sub BorrowerDGV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles BorrowerDGV.CellContentClick

    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click

    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub
End Class